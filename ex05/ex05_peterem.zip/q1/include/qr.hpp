void qr();

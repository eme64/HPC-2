void qr() {
    // TODO: implement the validation, serial and parallel profiling.
}

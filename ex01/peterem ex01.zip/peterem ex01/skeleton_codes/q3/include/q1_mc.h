#ifndef Q1_MC_H
#define Q1_MC_H

void q1_mc();

#endif 
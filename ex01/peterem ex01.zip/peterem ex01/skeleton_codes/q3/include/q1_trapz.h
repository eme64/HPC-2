#ifndef Q1_TRAPZ_H
#define Q1_TRAPZ_H

void q1_trapz();

#endif 